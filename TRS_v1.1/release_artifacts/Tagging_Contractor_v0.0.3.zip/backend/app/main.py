from fastapi import FastAPI
from .routes import router

app = FastAPI(title="Tagging_Contractor (TRS Service)", version="0.0.1-turnkey")
app.include_router(router)
