#!/usr/bin/env python3
import sys, hashlib, zipfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
ART = REPO_ROOT / "release_artifacts"
ART.mkdir(parents=True, exist_ok=True)

EXCLUDE_DIRS = {
    "release_artifacts",
    "Release_Artifacts",
    "_archive",
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".cache",
    ".venv",
    "venv",
    "myvenv",
    "node_modules",
}
EXCLUDE_FILES = {".DS_Store"}

def is_excluded(rel: Path) -> bool:
    if any(p in EXCLUDE_DIRS for p in rel.parts):
        return True
    if rel.name in EXCLUDE_FILES:
        return True
    return False

def iter_files():
    out = []
    for p in REPO_ROOT.rglob("*"):
        if p.is_dir():
            continue
        rel = p.relative_to(REPO_ROOT)
        if is_excluded(rel):
            continue
        out.append(p)
    return sorted(out, key=lambda x: str(x.relative_to(REPO_ROOT)))

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith("v"):
        print("Usage: python3 scripts/release.py vX.Y.Z")
        raise SystemExit(2)

    ver = sys.argv[1]
    files = iter_files()

    zip_name = f"Tagging_Contractor_{ver}.zip"
    man_name = f"Tagging_Contractor_{ver}_manifest.txt"
    sha_name = f"Tagging_Contractor_{ver}_sha256.txt"

    zip_path = ART / zip_name
    partial_zip = ART / (zip_name + ".partial")
    man_path = ART / man_name
    sha_path = ART / sha_name

    man_path.write_text(
        "".join(f"{p.relative_to(REPO_ROOT)}\t{p.stat().st_size}\n" for p in files),
        encoding="utf-8"
    )

    if partial_zip.exists():
        partial_zip.unlink()

    with zipfile.ZipFile(partial_zip, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        for p in files:
            z.write(p, arcname=str(p.relative_to(REPO_ROOT)))

    if zip_path.exists():
        zip_path.unlink()
    partial_zip.rename(zip_path)

    sha_path.write_text(f"{sha256(zip_path)}  {zip_name}\n", encoding="utf-8")
    (REPO_ROOT / "VERSION.txt").write_text(ver + "\n", encoding="utf-8")

    print("SUCCESS")
    print(zip_path)
    print(man_path)
    print(sha_path)

if __name__ == "__main__":
    main()
