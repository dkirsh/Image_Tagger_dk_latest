import os
import requests
import streamlit as st
import pandas as pd

API_URL = os.getenv("TRS_API_URL", "http://trs_api:8401")

st.set_page_config(page_title="Tagging_Contractor", layout="wide")
st.title("Tagging_Contractor — Tag Registry Service UI")

page = st.sidebar.radio(
    "Pages",
    ["Status", "Registry Browser", "Tag Inspector", "Resolve/Search", "Contracts", "Schemas"],
)

def get_json(path, params=None):
    r = requests.get(f"{API_URL}{path}", params=params, timeout=30)
    r.raise_for_status()
    return r.json()

if page == "Status":
    st.subheader("System Status")
    st.json(get_json("/status"))

elif page == "Registry Browser":
    st.subheader("Registry Browser")
    reg = get_json("/registry")
    tags = reg.get("tags", {})
    rows = []

    if isinstance(tags, dict):
        for k, v in tags.items():
            if isinstance(v, dict):
                rows.append({
                    "tag_id": k,
                    "canonical_name": v.get("canonical_name") or v.get("name"),
                    "status": v.get("status"),
                    "value_type": v.get("value_type"),
                    "domain": v.get("domain"),
                    "subdomain": v.get("subdomain"),
                })
    elif isinstance(tags, list):
        for v in tags:
            if isinstance(v, dict):
                tid = v.get("canonical_id") or v.get("tag_id") or v.get("id")
                rows.append({
                    "tag_id": tid,
                    "canonical_name": v.get("canonical_name") or v.get("name"),
                    "status": v.get("status"),
                    "value_type": v.get("value_type"),
                    "domain": v.get("domain"),
                    "subdomain": v.get("subdomain"),
                })

    df = pd.DataFrame(rows)
    if df.empty:
        st.warning("No tags parsed (check registry format).")
    else:
        # light filters
        domains = sorted([d for d in df["domain"].dropna().unique().tolist() if str(d).strip()])
        statuses = sorted([s for s in df["status"].dropna().unique().tolist() if str(s).strip()])
        domain = st.selectbox("Domain", ["(all)"] + domains)
        status = st.selectbox("Status", ["(all)"] + statuses)
        if domain != "(all)":
            df = df[df["domain"] == domain]
        if status != "(all)":
            df = df[df["status"] == status]
        st.dataframe(df, use_container_width=True, height=560)

elif page == "Tag Inspector":
    st.subheader("Tag Inspector")
    reg = get_json("/registry")
    tags = reg.get("tags", {})
    if isinstance(tags, dict) and tags:
        tag_id = st.selectbox("Tag ID", sorted(tags.keys()))
        st.json(tags[tag_id])
    elif isinstance(tags, list) and tags:
        # build mapping
        mapping = {}
        for v in tags:
            if isinstance(v, dict):
                tid = v.get("canonical_id") or v.get("tag_id") or v.get("id")
                if tid:
                    mapping[str(tid)] = v
        tag_id = st.selectbox("Tag ID", sorted(mapping.keys()))
        st.json(mapping[tag_id])
    else:
        st.warning("No tags found.")

elif page == "Resolve/Search":
    st.subheader("Resolve/Search")
    term = st.text_input("Search term (alias/name/tag id substring)", "")
    if term.strip():
        st.json(get_json("/resolve", params={"term": term, "limit": 25}))

elif page == "Contracts":
    st.subheader("Contracts")
    consumer = st.selectbox("Consumer (substring match in contract filename)", ["image_tagger", "article_eater", "bn", "pref"])
    st.json(get_json("/contracts/latest", params={"consumer": consumer}))

elif page == "Schemas":
    st.subheader("Schemas Viewer")
    st.caption("Enter a relative path under core/.../schemas/")
    rel = st.text_input("Relative schema path", "")
    if rel.strip():
        out = get_json(f"/schemas/{rel}")
        st.code(out["content"], language="json")
    else:
        st.info("Tip: list schema files locally under core/.../schemas/ to find the path.")
