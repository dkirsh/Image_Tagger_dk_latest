#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "== Tagging_Contractor Installer =="
echo "Repo: $REPO_ROOT"

chmod +x "$REPO_ROOT/bin/tc" 2>/dev/null || true
exec "$REPO_ROOT/bin/tc" up
