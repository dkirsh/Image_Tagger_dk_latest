# Repository Guidelines

## Project Structure & Module Organization
- `core/trs-core/v0.2.8/`: Vendored TRS core distribution bundle (do not edit unless updating the bundle).
- `backend/`: Backend/service code and supporting modules.
- `frontend_streamlit/`: Streamlit UI for browsing and inspection.
- `contracts/`: JSON schemas and contract artifacts.
- `docs/`: Design and implementation documentation (see `docs/neuroarch_localized_spec/`).
- `bin/`: Repo automation scripts (primary entry point: `./bin/tc`).
- `docker-compose.yml`, `Dockerfile.api`, `Dockerfile.ui`: Container orchestration and build definitions.

## Build, Test, and Development Commands
- `./bin/tc doctor`: Environment preflight (Docker present, core bundle exists).
- `./bin/tc up`: Build and start API + UI with Docker Compose.
- `./bin/tc down`: Stop running containers.
- `./bin/tc logs [service]`: Tail logs for all services or a named service.
- `./bin/tc status`: Show running containers and available release artifacts.
- `./bin/tc health`: Wait for API/UI to respond on localhost ports.
- `./install.sh`: Local setup helper (also invoked by `./bin/tc install`).

## Coding Style & Naming Conventions
- Match existing conventions in the file you touch; keep edits minimal.
- Python: 4-space indentation, PEP 8–style naming (`snake_case` for functions/vars, `CamelCase` for classes).
- Shell scripts: 2-space indentation, explicit `set -euo pipefail` when adding new scripts.
- Prefer descriptive, domain-specific names (e.g., `wall_separation`, `localized_pipeline`).

## Testing Guidelines
- No automated test suite is wired up in this repo.
- Use `./bin/tc doctor` before changes and verify runtime health:
  - API: `http://localhost:8401/health`
  - UI: `http://localhost:8501`
- For localized analyzers, see the mock example in `INSTALL.md` for a quick smoke check.

## Commit & Pull Request Guidelines
- Git metadata is not present in this checkout, so no commit convention can be inferred.
- Use clear, scoped commit messages (e.g., `docs: clarify install steps`).
- PRs should include: purpose, user impact, and any local verification performed.
- Link related issues or specs when applicable and include screenshots for UI changes.

## Configuration & Operations Notes
- `.env` is created by `./bin/tc` if missing; keep local overrides out of version control.
- This repo expects Docker Desktop to be installed and running before `./bin/tc up`.

## Agent-Specific Instructions
- No deletions: archive files under `_archive/` instead of removing them.
- URLs: provide the browser URL or use `open <url>` when sharing links.
