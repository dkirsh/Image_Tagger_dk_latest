#!/bin/bash
# collect_external.sh — one-run collector for every external model/tool in
# cnfa_algs/adapters/EXTERNAL_MODELS_CATALOG.md  (2026-07-13)
#
# Run on YOUR machine (Mac or lab GPU box) with normal internet:
#     bash collect_external.sh
# Everything lands under this script's directory:
#     cnfa_external/
#       weights/   Hugging Face checkpoints (segmentation, depth, detection, CLIP)
#       repos/     source repos (SpatialLM, GeoCalib, HorizonNet, MASt3R, depthmapX)
#       MANIFEST.txt  what landed, sizes, licenses, manual steps remaining
#
# Python packages install into the CURRENT environment; activate a venv first
# if you want isolation:  python3 -m venv .venv && source .venv/bin/activate
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)/cnfa_external"
mkdir -p "$ROOT/weights" "$ROOT/repos"
MAN="$ROOT/MANIFEST.txt"
echo "cnfa external collection $(date)" > "$MAN"

note() { echo "$1" | tee -a "$MAN"; }

# ---------------------------------------------------------------- pip layer
note "== pip packages =="
pip install --upgrade pip -q
for pkg in "pyroomacoustics" "transformers" "timm" "onnxruntime" \
           "huggingface_hub[cli]" "pillow" "opencv-python-headless" "scipy"; do
  pip install "$pkg" -q && note "pip OK: $pkg" || note "pip FAIL: $pkg"
done
# torch: CPU build by default; swap for CUDA build on the GPU box
pip install torch --index-url https://download.pytorch.org/whl/cpu -q \
  && note "pip OK: torch (cpu)" || note "pip FAIL: torch"

# ------------------------------------------------------------- HF weights
note "== Hugging Face checkpoints (into weights/) =="
hfget() {  # repo_id [subpath]
  hf download "$1" ${2:+--include "$2"} --local-dir "$ROOT/weights/$(basename "$1")" \
    && note "HF OK: $1" || note "HF FAIL: $1"
}
hfget nvidia/segformer-b2-finetuned-ade-512-512          # planes seg (check ckpt license)
hfget facebook/mask2former-swin-base-ade-semantic        # alt seg w/ instances (CC-BY-NC)
hfget onnx-community/depth-anything-v2-small "onnx/*"    # relative depth ONNX (Apache)
hfget Intel/zoedepth-nyu-kitti                           # METRIC depth via transformers (MIT)
hfget IDEA-Research/grounding-dino-tiny                  # open-vocab detection (Apache)
hfget google/owlv2-base-patch16-ensemble                 # open-vocab detection (Apache)
hfget openai/clip-vit-base-patch32                       # embeddings (MIT)
hfget manycore-research/SpatialLM1.1-Qwen-0.5B           # layout LLM (Apache base; encoder CC-BY-NC)

# ---------------------------------------------------------------- repos
note "== source repos (into repos/) =="
gget() { git clone --depth 1 "https://github.com/$1" "$ROOT/repos/$(basename "$1")" \
         && note "git OK: $1" || note "git FAIL: $1"; }
gget manycore-research/SpatialLM       # layout inference code
gget cvg/GeoCalib                      # focal/horizon from single image (pip installable too)
gget jinlinyi/PerspectiveFields        # alt camera calibration
gget sunset1995/HorizonNet             # panorama -> layout (MIT). NOTE: pretrained
                                       # .pth is on the repo's Google Drive link — manual step.
gget naver/mast3r                      # photos -> point cloud (weights: see repo README)
gget SpaceGroupUCL/depthmapX           # canonical VGA engine (build or grab release binary)

# ------------------------------------------------------------- wiring env
note "== environment wiring =="
DA="$ROOT/weights/depth-anything-v2-small/onnx/model.onnx"
if [ -f "$DA" ]; then
  note "Set in your shell profile:  export DEPTH_ANYTHING_ONNX_PATH=$DA"
fi

note "== manual steps remaining =="
note "1. HorizonNet pretrained weights: Google Drive link in repos/HorizonNet/README."
note "2. depthmapX: download the release binary for macOS or build from repos/depthmapX."
note "3. SpatialLM inference needs a CUDA box (see repos/SpatialLM, Python 3.11 env)."
note "4. Radiance/DAYSIM (daylight): install via https://www.radiance-online.org or brew."
note "5. Licenses: segformer ckpt = NVIDIA license; mask2former = CC-BY-NC;"
note "   SpatialLM1.1 encoder = CC-BY-NC; all fine for research, check before redistribution."

echo; echo "==== COLLECTION SUMMARY ===="; cat "$MAN"
du -sh "$ROOT/weights" "$ROOT/repos" 2>/dev/null
echo "Done. Point Claude at the manifest to wire adapters to these paths."
